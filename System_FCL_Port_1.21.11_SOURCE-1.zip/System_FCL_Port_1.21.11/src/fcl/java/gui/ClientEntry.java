package gui;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Android-safe Fabric entry point. No native Windows libraries are loaded. */
public final class ClientEntry implements ClientModInitializer {
    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.register(
                Identifier.fromNamespaceAndPath("mcgui", "main")
        );
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mcgui.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new FclMenuScreen());
                } else if (client.currentScreen instanceof FclMenuScreen) {
                    client.setScreen(null);
                }
            }
        });
    }
}
