package gui;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Touch-friendly Java replacement UI. Feature switches are UI-only until backed by native-free modules. */
public final class FclMenuScreen extends Screen {
    private static final int BG = 0xF20B101A;
    private static final int PANEL = 0xF2182231;
    private static final int PANEL_ALT = 0xF2222E40;
    private static final int ACCENT = 0xFF55D6BE;
    private static final int MUTED = 0xFF9AA9BC;
    private static final int WHITE = 0xFFF2F6FC;

    private static final Map<String, List<String>> MODULES = new LinkedHashMap<>();
    static {
        MODULES.put("Combat", List.of("Aim Assist", "Trigger Bot", "Auto Totem", "Crystal Tap", "Shield Breaker", "Projectile Aim"));
        MODULES.put("Movement", List.of("Sprint", "Free Cam", "Free Look", "No Jump Delay", "Elytra Swap", "Inv Move"));
        MODULES.put("Render", List.of("Player ESP", "Item ESP", "Block ESP", "Tracers", "Name Tags", "Full Bright"));
        MODULES.put("Player", List.of("Auto Tool", "Auto Swap", "Auto Respawn", "Auto Accept", "No Push", "No Slow"));
        MODULES.put("Utility", List.of("Waypoints", "Fast Search", "Chest Stealer", "Auto Sell", "Auto Cart", "Pearl Catch"));
        MODULES.put("Client", List.of("HUD", "Theme", "Sound", "Zoom", "Panic", "Safe Mode"));
    }

    private final Map<String, Boolean> enabled = new LinkedHashMap<>();
    private String selectedCategory = "Combat";
    private int scroll;
    private int panelX, panelY, panelW, panelH;

    public FclMenuScreen() {
        super(Text.literal("System — FCL Menu"));
        MODULES.values().forEach(items -> items.forEach(name -> enabled.put(name, false)));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        context.fill(0, 0, width, height, 0x99000000);
        panelW = Math.min(650, Math.max(300, width - 24));
        panelH = Math.min(410, Math.max(250, height - 24));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        context.fill(panelX + 3, panelY + 4, panelX + panelW + 3, panelY + panelH + 4, 0x55000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, BG);
        context.fill(panelX, panelY, panelX + panelW, panelY + 3, ACCENT);

        context.drawTextWithShadow(textRenderer, Text.literal("SYSTEM"), panelX + 18, panelY + 15, WHITE);
        context.drawTextWithShadow(textRenderer, Text.literal("FCL  /  JAVA EDITION"), panelX + 18, panelY + 31, MUTED);
        context.drawTextWithShadow(textRenderer, Text.literal("×"), panelX + panelW - 19, panelY + 15, WHITE);
        context.fill(panelX + 14, panelY + 52, panelX + panelW - 14, panelY + 53, 0x553E5368);

        int railW = Math.min(132, panelW / 3);
        int contentX = panelX + railW + 20;
        int contentW = panelW - railW - 36;
        context.fill(panelX + 12, panelY + 64, panelX + railW, panelY + panelH - 38, PANEL);

        int cy = panelY + 76;
        for (String category : MODULES.keySet()) {
            boolean active = category.equals(selectedCategory);
            int color = active ? 0xFF294C54 : PANEL;
            context.fill(panelX + 18, cy - 5, panelX + railW - 6, cy + 23, color);
            if (active) context.fill(panelX + 18, cy - 5, panelX + 21, cy + 23, ACCENT);
            context.drawTextWithShadow(textRenderer, Text.literal(category), panelX + 29, cy + 4, active ? WHITE : MUTED);
            cy += 34;
        }

        context.drawTextWithShadow(textRenderer, Text.literal(selectedCategory.toUpperCase()), contentX, panelY + 69, WHITE);
        context.drawTextWithShadow(textRenderer, Text.literal("Tap a tile to switch its preview state"), contentX, panelY + 85, MUTED);

        List<String> items = MODULES.get(selectedCategory);
        int top = panelY + 112;
        int bottom = panelY + panelH - 44;
        int cardGap = 8;
        int columns = contentW >= 330 ? 2 : 1;
        int cardW = (contentW - cardGap * (columns - 1)) / columns;
        int cardH = 48;
        int rows = (items.size() + columns - 1) / columns;
        int maxScroll = Math.max(0, rows * (cardH + 8) - (bottom - top));
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        context.enableScissor(contentX, top, contentX + contentW, bottom);
        for (int i = 0; i < items.size(); i++) {
            int col = i % columns;
            int row = i / columns;
            int x = contentX + col * (cardW + cardGap);
            int y = top + row * (cardH + 8) - scroll;
            String name = items.get(i);
            boolean on = enabled.getOrDefault(name, false);
            boolean hover = mouseX >= x && mouseX <= x + cardW && mouseY >= y && mouseY <= y + cardH;
            context.fill(x, y, x + cardW, y + cardH, hover ? PANEL_ALT : PANEL);
            context.fill(x, y, x + 3, y + cardH, on ? ACCENT : 0xFF3A485A);
            context.drawTextWithShadow(textRenderer, Text.literal(name), x + 12, y + 10, WHITE);
            context.drawTextWithShadow(textRenderer, Text.literal(on ? "ON" : "OFF"), x + 12, y + 27, on ? ACCENT : MUTED);
            int sx = x + cardW - 42;
            int sy = y + 16;
            context.fill(sx, sy, sx + 30, sy + 16, on ? 0xFF287B70 : 0xFF3A4656);
            int knobX = on ? sx + 17 : sx + 2;
            context.fill(knobX, sy + 2, knobX + 11, sy + 14, WHITE);
        }
        context.disableScissor();

        context.drawTextWithShadow(textRenderer, Text.literal("UI PORT • MODULE LOGIC NOT CONNECTED"), panelX + 18, panelY + panelH - 25, 0xFFFFC978);
        context.drawTextWithShadow(textRenderer, Text.literal("Right Shift: close  •  touch supported"), panelX + panelW - 205, panelY + panelH - 25, MUTED);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x();
        double my = click.y();
        if (mx >= panelX + panelW - 30 && my >= panelY && my <= panelY + 48) {
            close();
            return true;
        }
        int railW = Math.min(132, panelW / 3);
        int cy = panelY + 76;
        for (String category : MODULES.keySet()) {
            if (mx >= panelX + 18 && mx <= panelX + railW - 6 && my >= cy - 5 && my <= cy + 23) {
                selectedCategory = category;
                scroll = 0;
                return true;
            }
            cy += 34;
        }
        int contentX = panelX + railW + 20;
        int contentW = panelW - railW - 36;
        int top = panelY + 112;
        int bottom = panelY + panelH - 44;
        int columns = contentW >= 330 ? 2 : 1;
        int cardGap = 8;
        int cardW = (contentW - cardGap * (columns - 1)) / columns;
        int cardH = 48;
        List<String> items = MODULES.get(selectedCategory);
        for (int i = 0; i < items.size(); i++) {
            int col = i % columns;
            int row = i / columns;
            int x = contentX + col * (cardW + cardGap);
            int y = top + row * (cardH + 8) - scroll;
            if (mx >= x && mx <= x + cardW && my >= Math.max(top, y) && my <= Math.min(bottom, y + cardH)) {
                String name = items.get(i);
                enabled.put(name, !enabled.getOrDefault(name, false));
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, scroll - (int) (verticalAmount * 28));
        return true;
    }
}
